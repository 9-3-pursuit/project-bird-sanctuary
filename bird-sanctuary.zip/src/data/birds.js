const birdData = [
  {
    img: "https://cdn.pixabay.com/photo/2020/06/03/13/47/bird-5255017_960_720.jpg",
    name: "Shoebill",
    amount: 100,
    id: 444,
  },
  {
    img: "https://i.imgur.com/20pjOv5b.jpg",
    name: "Resplendent Quetzal",
    amount: 200,
    id: 555,
  },
  {
    img: "https://i.imgur.com/GacKN4tb.jpg",
    name: "Royal Flycatcher",
    amount: 300,
    id: 777,
  },
  {
    img: "https://i.redditmedia.com/sl3adn3eXY65Y4yNLxMRO_O4y-Pf1EYCxPuHpV34WqI.jpg?fit=crop&crop=faces%2Centropy&arh=2&w=640&s=f461fa6cd525892f85eb89268550867a",
    name: "Boat Billed Heron",
    amount: 600,
    id: 1333,
  },
  {
    img: "https://i.imgur.com/vHQizcwb.jpg",
    name: "Turaco",
    amount: 400,
    id: 888,
  },

  {
    img: "https://i.imgur.com/YHApS55.png",
    name: "King Vulture",
    amount: 500,
    id: 1010,
  },
  {
    img: "https://i.imgur.com/ZkvJHL8b.jpg",
    name: "Frilled Coquette Hummingbird",
    amount: 600,
    id: 1212,
  },

  {
    img: "https://i.imgur.com/VGAxKX1.png",
    name: "tweetr",
    amount: 10000,
    id: 999,
  },
  {
    img: "https://static.independent.co.uk/s3fs-public/thumbnails/image/2014/07/14/15/MPP.jpg?w968h681",
    name: "Ex Parrot",
    amount: 700,
    id: 2424,
  },
];

export default birdData;
