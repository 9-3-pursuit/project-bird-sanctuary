# How did this assignment go?

## Completion 1 -5

My self-assessed completion score is \_\_\_\_

5: I did everything required and attempted at least one bonus

4: I attempted all parts of the lab and completed most/all of the required parts of the assignment

3: I was able to attempt most parts of the lab and got some of the required parts done

2: I was only able to make a little progress

1: I got completely stuck and/or did not have enough time to work on this assignment

## Comfort 1- 5

My self-assessed comfort score is \_\_\_\_

5: This assignment was a breeze! I want more challenges

4: This assignment was a bit challenging but I learned a lot

3: There were some required parts of this assignment that were too hard for me to complete

2: I really struggled to understand what to do for this assignment, but I think I still made some progress

1: I feel completely lost and I was not able to further my understanding

## Wins

Please list any wins:

## Struggles

Please list any specific struggles

## Other comments

Please add any other things you'd like us to know about this assignment

quicktest
